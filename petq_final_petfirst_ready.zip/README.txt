Final PetQ AI (keep current structure + add Pet-first)

- keeps current public structure
- keeps contact email block exactly
- adds only Pet-first feeling, dog and cat visuals in some places
